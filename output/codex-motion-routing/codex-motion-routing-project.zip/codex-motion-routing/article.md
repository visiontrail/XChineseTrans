# How I used Codex to make a motion video from a director brief

A gold packet follows a path. A connection breaks. The packet takes another route and reaches the same destination.

That is the entire story of this 24-second film. Keeping the story that small made it possible to work on the parts that matter: where the viewer looks, how an action develops, when sound arrives, and whether the finished file actually plays.

Codex built the composition in React and SVG, rendered it through Remotion, and generated an original soundtrack with Python. The result is a 1920 × 1080 MP4 at 60 frames per second. No stock footage, external song, or video-generation model was used.

The useful part of this experiment is the production method. A short director brief became a shot map, a shared event timeline, executable motion, and a set of checks against the rendered result.

## Give the video one job

The brief started with a sentence: show how an alternate path preserves a destination when one connection fails.

This is a routing metaphor. It does not simulate a routing protocol, measure failover time, or show a captured packet moving through a real network. That boundary also guided the animation: the packet waits at a router while the connection changes, rather than bouncing backward off a broken cable.

A narrow subject helps an agent make coherent choices. Here, the gold circle is the subject, green lines describe the active path, and pale lines show alternatives. The destination stays in the same place throughout the network sequence.

The visual rules were equally specific: warm ivory, forest green, a little gold, Geist typography, and generous margins. No gradients, glow, cards, or whole-frame shaking. A flat diagram did not need simulated studio lighting.

## Write the shot map before the animation

The 24 seconds were divided into six sections:

| Time | What changes | What the viewer should understand |
|---|---|---|
| 0–3.5 s | A gold subject appears inside moving paths | This story follows one packet |
| 3.5–7.5 s | The network opens and the packet reaches a router | A direct path exists |
| 7.5–11.5 s | The direct connection breaks | The original path is unavailable |
| 11.5–15.5 s | An upper branch becomes active | Another route is available |
| 15.5–19.5 s | The packet crosses that branch and arrives | The destination has not changed |
| 19.5–24 s | The network recedes into the closing composition | Resilience needs an alternative |

Each section has one main job. The titles arrive after the corresponding visual action begins. They hold long enough to read, then leave before the next title enters.

The gold subject remains continuous through the sequence. Its opening circle contracts into the packet, travels through the graph, and expands again in the closing composition. This gives the film a visual thread without adding more objects.

## Make time a shared input

The score uses 120 BPM. At 60 fps, one beat is 30 frames:

```text
frames per beat = fps × 60 / BPM
                = 60 × 60 / 120
                = 30
```

The central file is a small event table. It places the link break at frame 480, the alternate-route cue at 720, and arrival at 1110. Those correspond to 8, 12, and 18.5 seconds.

```json
{"id": "break", "frame": 480, "kind": "snap", "pan": 0.2}
```

Both the animation and the sound generator read the event data. A change to an event can therefore move the related picture and sound together. Some actions deliberately lead or follow the event: the cable ends respond a few frames apart, and the second arrival ring starts 11 frames after the packet arrives.

A beat grid is useful for organizing emphasis. It does not require every element to move on every beat. The quieter hold after the break gives the viewer time to understand what changed.

## Turn motion into a function of the frame

In this composition, the frame number determines the image. There are no wall-clock timers, CSS transitions, or accumulated simulation state.

The subject position follows line segments and cubic Bézier curves. A smooth progress function controls acceleration and deceleration. Its speed is estimated from neighboring positions:

```text
speed(frame) = distance(position(frame + 0.5),
                        position(frame - 0.5))
```

The faster the packet moves, the more it stretches along its direction of travel. The perpendicular axis shrinks by the reciprocal amount. That preserves the ellipse's area and avoids making the object appear to gain mass as it accelerates.

The broken cable uses a damped oscillation:

```text
displacement = amplitude × exp(-decay × elapsedFrames)
                         × sin(frequency × elapsedFrames)
```

The motion begins at the break and loses energy over time. Nearby nodes respond later. These are designed physical cues rather than a full physics engine, but their causes are explicit and their behavior is reproducible.

Remotion supplies the frame-based composition and rendering machinery. The story, timing, geometry, and motion rules remain project code. Its [fundamentals guide](https://www.remotion.dev/docs/the-fundamentals) describes the underlying frame model.

## Let sound follow the events

Python generates a 48 kHz stereo soundtrack from oscillators, filtered noise, envelopes, and a fixed random seed.

The music bed provides sparse plucked tones and a restrained pulse. Event sounds carry the local actions: a sweep for the network unfolding, a short snap for the broken connection, taps at the intermediate nodes, and a resolving chord at arrival. The bed becomes quieter around the break so that the snap has room.

There is no narration. The short titles and the changing diagram carry the meaning when the video is muted. Sound adds rhythm and emphasis without having to explain the scene.

Sharing an event timestamp is only the first step in synchronization. A sound can have a slow attack or an intentionally early sweep. Its onset and envelope still need inspection against the image.

## Inspect cheap frames before rendering the full film

The first visual check caught a defect that the source code alone did not make obvious.

The paper texture was in an absolutely positioned layer, while the SVG artwork was not explicitly positioned. The paper ended up painting over the text and lines. The colors were correct in the source, but the rendered film looked pale and had poor contrast.

Giving the SVG its own positioned layer above the paper fixed it. The failed frames were retained so the correction could be compared directly.

Two smaller changes followed: the scene headings moved down 33 pixels to separate them from the persistent header, and a restrained rotating arc was added around the router during its decision hold. The arc gives the pause a purpose without pulling attention away from the packet.

These are concrete revision instructions. “Make it more premium” would not have identified the stacking problem, the spacing adjustment, or the silent hold.

## Review the motion and the encoded file

Key frames cover the opening, each route state, the break, arrival, and the ending. Extra samples around the break and arrival make small timing errors easier to spot. A contact sheet provides an overview, while the full-size images reveal text and line quality.

The local review page adds event buttons, a frame target, and one-frame stepping. It also reports the presentation timestamp delivered by the browser. That distinction matters: asking a player to seek to a time and seeing which frame it actually displays are separate observations.

A numerical pass evaluates the subject across all 1,440 frames. It checks for invalid values, safe-area violations, and large position jumps. Those checks catch mechanical errors; they do not decide whether the rhythm is good.

The final export also goes through FFprobe inspection, a complete FFmpeg decode, and audio analysis. The file has to contain the intended video and audio streams, retain the planned duration, and survive playback and seeking. Remotion's [renderMedia documentation](https://www.remotion.dev/docs/renderer/render-media) covers the export controls used here.

That inspection led to a final mastering pass. The raw export used full-range video and included a short AAC padding tail. FFmpeg converted the deliverable to limited-range H.264 4:2:0 with BT.709 metadata and an exact 24-second duration. The initial soundtrack was also quiet; measured normalization brought the final encoded audio to about -18.4 LUFS, with a true peak of -2.0 dBTP. A loudness target is a setting; these figures come from measuring the delivered file.

## Keep the project reusable

The reusable unit is the set of small files around the animation:

```text
brief.md                 story, constraints and shot map
public/timeline.json     named events and frame numbers
src/motion.ts            position and deformation functions
src/Film.tsx             visual layers and typography
scripts/soundtrack.py    original score and event sounds
scripts/render.mjs       key frames and final video
scripts/master.mjs       delivery color and audio mastering
review.html              playback and frame inspection
```

For another topic, start by changing the story and event map. Then adapt the geometry and sound vocabulary. Keep the render and review steps intact.

A useful starting prompt is:

> Create a 24-second motion explainer with one persistent visual subject. First write a director brief and a six-shot map. Specify the main event, visual hierarchy, motion cause, text timing, and sound cue for each shot. Put key events in a shared frame-based timeline. Render representative frames before the full video, inspect them, fix specific defects, and deliver the MP4 with the editable source and a record of the checks performed.

This project provides one tested workflow for a short diagram-led film. A different subject still needs its own story and motion decisions. The reusable practice is to make those decisions explicit, put key timing in data, inspect the rendered result, and revise the specific problems that appear.
